#ifndef LIB_WIFI_H
#define LIB_WIFI_H

#include <WiFi.h>

void setupWiFi();
void setupWiFiStation();
void connectToWiFi();

#endif